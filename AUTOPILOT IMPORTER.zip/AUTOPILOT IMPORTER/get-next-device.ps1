Clear-Host

$hashPath = "\\storage\data\HASH Files"
$processedPath = Join-Path $hashPath "processed"
$failedPath = Join-Path $hashPath "failed"

New-Item -ItemType Directory -Force -Path $processedPath | Out-Null
New-Item -ItemType Directory -Force -Path $failedPath | Out-Null

$configPath = Join-Path $PSScriptRoot "autopilot-config.json"
$config = Get-Content $configPath -Raw | ConvertFrom-Json

$logFile = Join-Path $PSScriptRoot "autopilot-log.txt"

function Log {
    param ($msg)
    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$time - $msg" | Tee-Object -FilePath $logFile -Append
}

# ===============================
# AUTH FUNCTION
# ===============================
function Get-AuthHeaders {
    param ($tenant)

    $body = @{
        client_id     = $tenant.clientId
        scope         = "https://graph.microsoft.com/.default"
        client_secret = $tenant.clientSecret
        grant_type    = "client_credentials"
    }

    $response = Invoke-RestMethod -Method Post `
        -Uri "https://login.microsoftonline.com/$($tenant.tenantId)/oauth2/v2.0/token" `
        -Body $body

    return @{
        Authorization = "Bearer $($response.access_token)"
        "Content-Type" = "application/json"
    }
}

# ===============================
# EXPORT FUNCTION
# ===============================
function Export-AutopilotDevices {

    param ($tenant, $name)

    Write-Host "`nExporting Autopilot devices for $name..." -ForegroundColor Yellow
    Log "EXPORT STARTED for $name"

    $headers = Get-AuthHeaders $tenant

    $allDevices = @()
    $uri = "https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities"

    while ($uri) {
        $response = Invoke-RestMethod -Method Get -Uri $uri -Headers $headers
        $allDevices += $response.value
        $uri = $response.'@odata.nextLink'
    }

    $export = $allDevices | Select-Object `
        serialNumber,
        displayName,
        groupTag,
        manufacturer,
        model,
        enrollmentState,
        lastContactedDateTime,
        id

    $timestamp = Get-Date -Format "yyyy-MM-dd-HHmm"
    $fileName = "$name-Autopilot-Export-$timestamp.csv"
    $desktop = [Environment]::GetFolderPath("Desktop")
    $fullPath = Join-Path $desktop $fileName

    $export | Export-Csv -Path $fullPath -NoTypeInformation

    Write-Host "`nExport complete: $fullPath" -ForegroundColor Green
    Log "EXPORT COMPLETE -> $fullPath"
}

# ===============================
# IMPORT FUNCTION (UNCHANGED CORE)
# ===============================
function Run-Import {

    param ($tenant, $name)

    $headers = Get-AuthHeaders $tenant
    $prefix = $tenant.prefix
    $groupTag = $tenant.groupTag

    Log "Starting run for $name"

    # get next number
    $devices = Invoke-RestMethod -Method Get `
        -Uri "https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities" `
        -Headers $headers

    $numbers = @()
    foreach ($d in $devices.value) {
        if ($d.displayName -and $d.displayName -like "$prefix*") {
            $num = ($d.displayName -replace $prefix, "") -as [int]
            if ($num) { $numbers += $num }
        }
    }

    $max = if ($numbers.Count -eq 0) { 0 } else { ($numbers | Measure -Maximum).Maximum }
    $next = $max + 1

    Log "Next device number: $prefix$next"

    $files = Get-ChildItem $hashPath -Filter *.csv
    if ($files.Count -eq 0) { return }

    $selected = $files

    $i = 0

    foreach ($file in $selected) {

        $serial = [System.IO.Path]::GetFileNameWithoutExtension($file.Name)
        $deviceName = "$prefix$($next + $i)"

        try {
            Log "Processing $serial"

            $devices = Invoke-RestMethod -Method Get `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities" `
                -Headers $headers

            $found = $devices.value | Where-Object {
                $_.serialNumber -eq $serial
            }

            if (-not $found) {
                throw "Device not found, skipping import for now"
            }

            if (-not $found.displayName) {
                Log "Naming -> $deviceName"

                $body = @{
                    displayName = $deviceName
                } | ConvertTo-Json

                Invoke-RestMethod -Method Post `
                    -Uri "https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities/$($found.id)/UpdateDeviceProperties" `
                    -Headers $headers `
                    -Body $body
            }

            Move-Item $file.FullName (Join-Path $processedPath $file.Name) -Force

        } catch {
            Log "FAILED: $serial -> $_"
            Move-Item $file.FullName (Join-Path $failedPath $file.Name) -Force
        }

        $i++
    }

    Log "RUN COMPLETE"
}

# ===============================
# MAIN MENU
# ===============================
while ($true) {

    Clear-Host
    Write-Host "AUTOPILOT TOOL" -ForegroundColor Cyan
    Write-Host "----------------------"
    Write-Host "1. GoVine"
    Write-Host "2. GreenVine"
    Write-Host "3. CareCircle"
    Write-Host ""
    Write-Host "T. Troubleshooting"
    Write-Host "X. Exit"

    $choice = Read-Host "Select option"

    switch ($choice) {

        "1" { Run-Import $config.govine "GoVine" }
        "2" { Run-Import $config.greenvine "GreenVine" }
        "3" { Run-Import $config.carecircle "CareCircle" }

        "T" {
            Clear-Host
            Write-Host "EXPORT MENU" -ForegroundColor Yellow
            Write-Host "1. GoVine"
            Write-Host "2. GreenVine"
            Write-Host "3. CareCircle"

            $sub = Read-Host "Select tenant to export"

            switch ($sub) {
                "1" { Export-AutopilotDevices $config.govine "GoVine" }
                "2" { Export-AutopilotDevices $config.greenvine "GreenVine" }
                "3" { Export-AutopilotDevices $config.carecircle "CareCircle" }
            }

            Read-Host "`nPress ENTER to return"
        }

        "x" { break }
        "X" { break }
    }

    Read-Host "`nPress ENTER to return"
}