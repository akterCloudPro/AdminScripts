@echo off
cd /d C:\scripts

powershell.exe -ExecutionPolicy Bypass -File "get-next-device.ps1"

pause