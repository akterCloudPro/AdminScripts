Clear-Host

$hashPath = "\\storage\data\HASH Files"
$processedPath = Join-Path $hashPath "processed"
$failedPath = Join-Path $hashPath "failed"

New-Item -ItemType Directory -Force -Path $processedPath | Out-Null
New-Item -ItemType Directory -Force -Path $failedPath | Out-Null

$configPath = Join-Path $PSScriptRoot "autopilot-config.json"
$config = Get-Content $configPath -Raw | ConvertFrom-Json

function Run-Import {

    param ($tenant, $name)

    $tenantId = $tenant.tenantId
    $clientId = $tenant.clientId
    $clientSecret = $tenant.clientSecret
    $prefix = $tenant.prefix
    $groupTag = $tenant.groupTag

    Write-Host "`nAuthenticating..." -ForegroundColor DarkGray

    $body = @{
        client_id     = $clientId
        scope         = "https://graph.microsoft.com/.default"
        client_secret = $clientSecret
        grant_type    = "client_credentials"
    }

    $response = Invoke-RestMethod -Method Post `
        -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
        -Body $body

    $headers = @{
        Authorization = "Bearer $($response.access_token)"
        "Content-Type" = "application/json"
    }

    Write-Host "Pulling existing devices..." -ForegroundColor DarkGray

    $devices = Invoke-RestMethod -Method Get `
        -Uri "https://graph.microsoft.com/v1.0/deviceManagement/managedDevices" `
        -Headers $headers

    $numbers = @()
    foreach ($d in $devices.value) {
        if ($d.deviceName -and $d.deviceName -like "$prefix*") {
            $num = ($d.deviceName -replace $prefix, "") -as [int]
            if ($num) { $numbers += $num }
        }
    }

    $max = if ($numbers.Count -eq 0) { 0 } else { ($numbers | Measure -Maximum).Maximum }
    $next = $max + 1

    Write-Host "`nNext starting number: $prefix$next" -ForegroundColor Green

    $files = Get-ChildItem $hashPath -Filter *.csv

    if ($files.Count -eq 0) {
        Write-Host "No hash files found." -ForegroundColor Red
        return
    }

    Write-Host "Available hashes: $($files.Count)"

    $inputCount = Read-Host "How many devices? (or ALL, 0 to go back)"

    if ($inputCount -eq "0") { return }

    if ($inputCount -eq "ALL") {
        $selected = $files
    } else {
        $selected = $files | Select-Object -First ([int]$inputCount)
    }

    $i = 0
    $results = @()

    foreach ($file in $selected) {

        $deviceName = "$prefix$($next + $i)"
        $serial = [System.IO.Path]::GetFileNameWithoutExtension($file.Name)

        Write-Host "Processing $serial -> $deviceName"

        try {
            $csv = Import-Csv $file.FullName

            $payload = @{
                importedWindowsAutopilotDeviceIdentities = @()
            }

            foreach ($row in $csv) {
                $payload.importedWindowsAutopilotDeviceIdentities += @{
                    serialNumber = $row."Device Serial Number"
                    hardwareIdentifier = $row."Hardware Hash"
                    groupTag = $groupTag
                }
            }

            $json = $payload | ConvertTo-Json -Depth 5

            Invoke-RestMethod -Method Post `
                -Uri "https://graph.microsoft.com/beta/deviceManagement/importedWindowsAutopilotDeviceIdentities/import" `
                -Headers $headers `
                -Body $json | Out-Null

            Move-Item $file.FullName (Join-Path $processedPath $file.Name) -Force

            # ADD TO CSV OUTPUT
            $results += [PSCustomObject]@{
                Serial = $serial
                DeviceName = $deviceName
                Tenant = $name
            }
        }
        catch {
            Write-Host "FAILED: $serial" -ForegroundColor Red
            Move-Item $file.FullName (Join-Path $failedPath $file.Name) -Force
        }

        $i++
    }

    # ===============================
    # EXPORT CSV
    # ===============================
    if ($results.Count -gt 0) {

        $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
        $outputFile = Join-Path $hashPath "IMPORT_RESULTS_$timestamp.csv"

        $results | Export-Csv $outputFile -NoTypeInformation

        Write-Host "`nCSV CREATED:" -ForegroundColor Cyan
        Write-Host $outputFile -ForegroundColor Green
    }

    Write-Host "`nDONE." -ForegroundColor Green
}

while ($true) {

    Clear-Host
    Write-Host "AUTOPILOT IMPORT TOOL" -ForegroundColor Cyan
    Write-Host "----------------------"
    Write-Host "1. GoVine"
    Write-Host "2. GreenVine"
    Write-Host "3. CareCircle"
    Write-Host ""
    Write-Host "X. Exit"

    $choice = Read-Host "Select option"

    switch ($choice) {
        "1" { Run-Import $config.govine "GoVine" }
        "2" { Run-Import $config.greenvine "GreenVine" }
        "3" { Run-Import $config.carecircle "CareCircle" }
        "x" { break }
        "X" { break }
    }

    Read-Host "`nPress ENTER to return"
}